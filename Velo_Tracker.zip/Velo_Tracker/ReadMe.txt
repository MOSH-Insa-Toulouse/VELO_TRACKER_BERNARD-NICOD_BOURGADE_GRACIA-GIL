Projet MOSH Velo-Tracker 2018-2019
Version 1.0
Réalisé par :
	- Coline Bernard-Nicod
	- Mathilde Bourgade
	- Théo Gracia-Gil

Le dossier zip inclut:
	- code Arduino
	- application Android (fichier .aia) utilisable sous MIT APP INVENTOR
	- fichier de conception hardware KICAD (schématique + PCB déjà routé prêt au tirage)
	
Objectifs du projet :
	- conception d'un objet communiquant basé sur Arduino ;
	- utilisation de sous-systèmes électroniques (module BT, module GPS) communiquant avec la carte Arduino ;
	- conception et réalisation d'un circuit imprimé (PCB) sous KiCAD.
	
Evolutions et perspectives de développement futur :
	- établir la communication module bluetooth vers téléphone ;
	- générer et imprimer le typon puis tirer le PCB ;
	- revoir la fonction du calcul de distance embarquée sur la carte Arduino.
	
Le prototype hardware sur breadboard se trouve au GP.